package dev.autoforge.app

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

data class Job(
    val id: String, val prompt: String, val appName: String?, val status: String, val stage: String,
    val progress: Int, val log: List<String>, val attempts: Int, val error: String?,
    val assumptions: List<String>, val limitations: List<String>, val createdAt: Long
) {
    val running get() = status == "queued" || status == "running"
    val done get() = status == "done"
}

private fun JSONArray?.strings(): List<String> = if (this == null) emptyList() else List(length()) { getString(it) }

private fun JSONObject.toJob() = Job(
    getString("id"), getString("prompt"), optString("appName").takeIf { it.isNotEmpty() && it != "null" },
    getString("status"), getString("stage"), getInt("progress"), optJSONArray("log").strings(), getInt("attempts"),
    optString("error").takeIf { it.isNotEmpty() && it != "null" }, optJSONArray("assumptions").strings(),
    optJSONArray("limitations").strings(), getLong("createdAt")
)

class Api(ctx: Context) {
    // The device token only identifies this install to the backend. It is NOT an AI credential.
    private val prefs = ctx.getSharedPreferences("af", Context.MODE_PRIVATE)
    private var base = (prefs.getString("server", null) ?: BuildConfig.BACKEND_URL).trimEnd('/')
    private val http = OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS).readTimeout(120, TimeUnit.SECONDS).build()
    private val json = "application/json".toMediaType()

    fun serverUrl(): String = base

    // Lets the user point the app at a reachable backend at runtime (no rebuild needed).
    fun setServerUrl(url: String) {
        var u = url.trim().trimEnd('/')
        if (u.isNotEmpty() && !u.startsWith("http://") && !u.startsWith("https://")) u = "http://$u"
        if (u.isEmpty() || u == base) return
        base = u
        prefs.edit().putString("server", u).remove("token").apply() // token belongs to the old server
    }

    private fun token(): String {
        prefs.getString("token", null)?.let { return it }
        http.newCall(Request.Builder().url("$base/v1/register").post("".toRequestBody()).build()).execute().use { r ->
            if (!r.isSuccessful) error("Cannot reach AutoForge server (${r.code})")
            val t = JSONObject(r.body!!.string()).getString("token")
            prefs.edit().putString("token", t).apply()
            return t
        }
    }

    private fun req(path: String) = Request.Builder().url(base + path).header("Authorization", "Bearer " + token())

    private fun call(r: Request): String = http.newCall(r).execute().use { resp ->
        val body = resp.body?.string().orEmpty()
        if (!resp.isSuccessful) error(runCatching { JSONObject(body).getString("error") }.getOrDefault("Server error ${resp.code}"))
        body
    }

    suspend fun createJob(prompt: String, ui: String, language: String): Job = withContext(Dispatchers.IO) {
        val b = JSONObject().put("prompt", prompt).put("ui", ui).put("language", language).toString().toRequestBody(json)
        JSONObject(call(req("/v1/jobs").post(b).build())).toJob()
    }
    suspend fun getJob(id: String): Job = withContext(Dispatchers.IO) { JSONObject(call(req("/v1/jobs/$id").build())).toJob() }
    suspend fun listJobs(): List<Job> = withContext(Dispatchers.IO) {
        val a = JSONArray(call(req("/v1/jobs").build())); List(a.length()) { a.getJSONObject(it).toJob() }
    }
    suspend fun deleteJob(id: String) = withContext(Dispatchers.IO) { call(req("/v1/jobs/$id").delete().build()); Unit }

    suspend fun download(path: String, dest: File): File = withContext(Dispatchers.IO) {
        dest.parentFile?.mkdirs()
        http.newCall(req(path).build()).execute().use { r ->
            if (!r.isSuccessful) error("Download failed (${r.code})")
            dest.outputStream().use { out -> r.body!!.byteStream().copyTo(out) }
        }
        dest
    }
}
