# AutoForge — idea → APK

```
Android client (Compose)  --HTTPS-->  Backend (Node)  --->  Anthropic API (key lives only here)
                                         |
                                         +--> Docker builder (no network, CPU/RAM/time capped) --> app-debug.apk
Pipeline: Planner → UI Designer → Developer → Build → Error Analyzer → Repair Agent (≤5 loops) → Exporter
```

## Layout
- `backend/src/server.js` API, device tokens, rate limit, job queue
- `backend/src/pipeline.js` the agent workflow and retry loop
- `backend/src/agents.js` Planner, UI Designer, Developer, Repair prompts
- `backend/src/builder.js` isolated Docker build + compiler-error analyzer
- `backend/src/template.js` Gradle scaffold owned by AutoForge (model cannot edit build scripts)
- `backend/builder/Dockerfile` JDK17 + Gradle 8.9 + Android SDK 34
- `android/` the AutoForge app: text/voice input, Kotlin/Java + Compose/XML choice, live progress, history, install, source export

## Setup
Requirements for the backend host: Linux, Node 20+, Docker, `zip`, ~8 GB RAM, ~15 GB disk.
```
cd backend && npm install
cp .env.example .env            # set ANTHROPIC_API_KEY and SERVER_SECRET
docker build -t autoforge-builder builder/
npm run warm                    # one-time, needs internet: fills offline Gradle cache volume
set -a; . ./.env; set +a; npm start
```
Android client: set `autoforgeBackend=https://your-host/` in `android/gradle.properties`, then
`cd android && gradle assembleDebug` (or open in Android Studio). Put the backend behind HTTPS (Caddy/nginx) for release builds; cleartext is only enabled in debug.

## Security model
- The APK contains only a random device token (HMAC-signed by the server). No AI key anywhere in it.
- Builds run with `--network none`, memory/CPU/pid limits, 15 min timeout, `no-new-privileges`.
- Model output is restricted to `app/src/main/**`, whitelisted extensions, no path traversal. Gradle files are never model-controlled.
- Per-device daily job limit (`MAX_JOBS_PER_DAY`).

## Honest limitations
- **Not yet run end to end.** This was written without Docker or internet access, so the build loop, Gradle versions and Docker flags are unverified. Run `npm run warm` first; fix any version mismatch it reports.
- Generated apps use a fixed dependency set (no Room, Retrofit, Firebase, Play Services, kapt/ksp). Ideas needing those, or a backend of their own, are reduced and listed under "Limitations" in the result screen.
- The Developer agent writes one-shot code; complex apps may exhaust the repair attempts and fail. Failure is reported, never faked.
- APKs are debug-signed: fine for sideloading, not Play Store. No release signing or AAB.
- Installing requires the user to grant "Install unknown apps"; Android always shows its own confirmation.
- Voice input uses the device's system speech recognizer; unavailable on devices without one.
- Job state is JSON files on disk with a single-process queue; scale-out needs a real DB/queue. Device tokens are anonymous (no accounts).
- Builder runs as root inside the container; harden with a rootless Docker/gVisor/Firecracker before exposing publicly.
