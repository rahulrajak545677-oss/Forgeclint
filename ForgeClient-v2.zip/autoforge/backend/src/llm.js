const MODEL = process.env.AUTOFORGE_MODEL || 'claude-sonnet-5-5';
const sleep = ms => new Promise(r => setTimeout(r, ms));

export async function ask({ system, user, maxTokens = 8000 }) {
  if (!process.env.ANTHROPIC_API_KEY) throw new Error('Server is missing ANTHROPIC_API_KEY');
  for (let i = 0; i < 4; i++) {
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({ model: MODEL, max_tokens: maxTokens, system, messages: [{ role: 'user', content: user }] })
    });
    if (r.status === 429 || r.status >= 500) { await sleep(2000 * (i + 1)); continue; }
    if (!r.ok) throw new Error('LLM error ' + r.status + ': ' + (await r.text()).slice(0, 300));
    const j = await r.json();
    return j.content.filter(b => b.type === 'text').map(b => b.text).join('');
  }
  throw new Error('LLM unavailable after retries');
}

export function extractJson(text) {
  const a = text.indexOf('{'), b = text.lastIndexOf('}');
  if (a < 0 || b < a) throw new Error('Model did not return JSON');
  return JSON.parse(text.slice(a, b + 1));
}

export function parseFiles(text) {
  const out = [];
  const re = /^=== FILE: (.+?) ===\r?\n([\s\S]*?)\r?\n=== END ===/gm;
  let m;
  while ((m = re.exec(text))) out.push({ path: m[1].trim(), content: m[2] });
  return out;
}
