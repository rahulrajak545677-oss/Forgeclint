import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

export const DATA = path.resolve(process.env.DATA_DIR || './data');
const jobsRoot = path.join(DATA, 'jobs');
fs.mkdirSync(jobsRoot, { recursive: true });
export const ID_RE = /^[0-9a-f-]{36}$/;
export const jobDir = id => path.join(jobsRoot, id);

export function createJob(deviceId, prompt, options) {
  const id = crypto.randomUUID();
  fs.mkdirSync(jobDir(id), { recursive: true });
  const job = { id, deviceId, prompt, options, status: 'queued', stage: 'queued', progress: 0, log: [], attempts: 0,
    createdAt: Date.now(), plan: null, error: null, apk: false };
  saveJob(job);
  return job;
}
export function saveJob(j) { fs.writeFileSync(path.join(jobDir(j.id), 'job.json'), JSON.stringify(j)); }
export function loadJob(id) {
  if (!ID_RE.test(id)) return null;
  try { return JSON.parse(fs.readFileSync(path.join(jobDir(id), 'job.json'), 'utf8')); } catch { return null; }
}
export function listJobs(deviceId) {
  return fs.readdirSync(jobsRoot).map(loadJob).filter(j => j && j.deviceId === deviceId).sort((a, b) => b.createdAt - a.createdAt);
}
export function deleteJob(id) { if (ID_RE.test(id)) fs.rmSync(jobDir(id), { recursive: true, force: true }); }
export function view(j) {
  return { id: j.id, prompt: j.prompt, appName: j.plan?.appName || null, status: j.status, stage: j.stage, progress: j.progress,
    log: j.log.slice(-60), attempts: j.attempts, error: j.error, apk: j.apk, createdAt: j.createdAt,
    assumptions: j.plan?.assumptions || [], limitations: j.plan?.limitations || [] };
}
