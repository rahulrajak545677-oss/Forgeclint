import { ask, extractJson, parseFiles } from './llm.js';
import { ALLOWED_DEPS_TEXT } from './template.js';

const RULES = `HARD RULES
- Never invent features that do not work. Every button, menu and setting must be wired to real logic.
- If something cannot be done on-device without a backend, paid API key or unavailable library, do NOT fake it: leave it out and list it under "limitations".
- Never require the user to enter API keys. Do not embed any secrets.
- Make reasonable default assumptions. Do not ask questions.
- ${ALLOWED_DEPS_TEXT}`;

export async function planner(prompt, opts) {
  const t = await ask({
    maxTokens: 3000,
    system: `You are the Planner of an autonomous Android app factory. Convert the user's idea into a concrete build plan. Output ONLY JSON:
{"appName":"","packageName":"com.autoforge.gen.<lowercasename>","summary":"","features":[""],"screens":[{"name":"","purpose":""}],"dataStorage":"","permissions":[""],"assumptions":[""],"limitations":[""]}
Keep scope achievable in ~10 source files. Prefer offline, on-device functionality (DataStore/SharedPreferences/files). ${RULES}`,
    user: `Idea: ${prompt}\nTarget: ${opts.mode === 'compose' ? 'Kotlin + Jetpack Compose' : opts.language === 'java' ? 'Java + XML views' : 'Kotlin + XML views'}`
  });
  return extractJson(t);
}

export async function uiDesigner(plan, opts) {
  const t = await ask({
    maxTokens: 3000,
    system: `You are the UI Designer. Produce a compact design spec as ONLY JSON:
{"style":"","colors":{"primary":"#RRGGBB","onPrimary":"","background":"","surface":"","accent":""},"typography":"","navigation":"","screens":[{"name":"","layout":"","components":[""],"states":["empty","error"]}]}
Material 3, accessible contrast, supports portrait phones. ${opts.mode === 'compose' ? 'Compose.' : 'XML layouts with ConstraintLayout/RecyclerView.'}`,
    user: JSON.stringify(plan)
  });
  return extractJson(t);
}

const FORMAT = `OUTPUT FORMAT: only file blocks, no prose, no markdown fences:
=== FILE: app/src/main/<path> ===
<full file content>
=== END ===
Only paths under app/src/main/ are accepted. Gradle files are managed by the build system and cannot be changed.`;

export async function developer(plan, design, opts) {
  const stack = opts.mode === 'compose' ? 'Kotlin + Jetpack Compose (single MainActivity : ComponentActivity using setContent)'
    : opts.language === 'java' ? 'Java 17 + XML layouts (MainActivity.java extends AppCompatActivity, findViewById or ViewBinding)'
    : 'Kotlin + XML layouts (MainActivity.kt extends AppCompatActivity, ViewBinding enabled)';
  const t = await ask({
    maxTokens: 16000,
    system: `You are the Developer. Write a complete, compilable Android app. Stack: ${stack}.
Package must equal "${plan.packageName}"; launcher activity "${plan.packageName}.MainActivity".
Required files: AndroidManifest.xml (declare only needed permissions; theme @style/Theme.Generated), res/values/strings.xml (must define app_name), res/values/themes.xml (style Theme.Generated, parent Theme.Material3.DayNight.NoActionBar), all sources/layouts/drawables you use.
No TODOs, no placeholder/stub logic, no unused screens. Persist user data. Handle empty and error states. Use only APIs available at API 26+.
${RULES}\n${FORMAT}`,
    user: `PLAN:\n${JSON.stringify(plan)}\nDESIGN:\n${JSON.stringify(design)}`
  });
  const files = parseFiles(t);
  if (!files.length) throw new Error('Developer agent produced no files');
  return files;
}

export async function repair(plan, analysis, attempt, opts) {
  const t = await ask({
    maxTokens: 16000,
    system: `You are the Repair Agent. The Gradle build failed. Fix the root causes with minimal changes. Output FULL replacement contents for every file you change (and any new file needed). Do not change package name. If a feature cannot compile reliably, remove it rather than stubbing it. Stack: ${opts.mode === 'compose' ? 'Kotlin+Compose' : opts.language === 'java' ? 'Java+XML' : 'Kotlin+XML'}.
${ALLOWED_DEPS_TEXT}\n${FORMAT}`,
    user: `Attempt ${attempt}. Parsed errors:\n${JSON.stringify(analysis.errors, null, 1)}\n\nLog excerpt:\n${analysis.tail}\n\nCurrent source of failing files:\n` +
      analysis.sources.map(s => `=== FILE: ${s.path} ===\n${s.content}\n=== END ===`).join('\n') +
      `\n\nPlan:\n${JSON.stringify(plan)}`
  });
  return parseFiles(t);
}
