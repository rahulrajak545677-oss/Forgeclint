import fs from 'fs';
import path from 'path';
import { spawn } from 'child_process';

const IMAGE = process.env.BUILDER_IMAGE || 'autoforge-builder';
export const VOLUME = 'autoforge-gradle';

// Isolated build: no network (offline Gradle cache volume), capped CPU/RAM/pids, hard timeout.
export function build(dir, { online = false } = {}) {
  return new Promise(resolve => {
    const args = ['run', '--rm', '--memory', '4g', '--cpus', '2', '--pids-limit', '1024', '--security-opt', 'no-new-privileges',
      ...(online ? [] : ['--network', 'none']),
      '-v', `${dir}:/project`, '-v', `${VOLUME}:/gradle-home`, '-e', 'GRADLE_USER_HOME=/gradle-home', '-w', '/project', IMAGE,
      'timeout', online ? '1800' : '900', 'gradle', 'assembleDebug', ...(online ? [] : ['--offline']), '--no-daemon', '--console=plain'];
    const p = spawn('docker', args);
    let log = '';
    const add = d => { log += d.toString(); if (log.length > 400000) log = log.slice(-300000); };
    p.stdout.on('data', add); p.stderr.on('data', add);
    p.on('error', e => resolve({ ok: false, log: 'Failed to start docker: ' + e.message, apk: null }));
    p.on('close', code => {
      const apk = path.join(dir, 'app/build/outputs/apk/debug/app-debug.apk');
      resolve({ ok: code === 0 && fs.existsSync(apk), log, apk: fs.existsSync(apk) ? apk : null });
    });
  });
}

// Error analyzer: structured compiler errors + context
export function analyze(log, dir) {
  const errors = [];
  const seen = new Set();
  for (const line of log.split('\n')) {
    let m = line.match(/^e: (?:file:\/\/)?(\/project\/\S+?):(\d+):(\d+):? (.*)$/) ||
            line.match(/^(\/project\/\S+?\.java):(\d+): error: (.*)$/) ||
            line.match(/^(\/project\/\S+?\.xml):(\d+):?(?:\d+)?:? (?:AAPT: )?error: (.*)$/);
    if (m) {
      const file = m[1].replace('/project/', '');
      const msg = m[m.length - 1];
      const key = file + m[2] + msg;
      if (!seen.has(key)) { seen.add(key); errors.push({ file, line: +m[2], message: msg }); }
    }
  }
  const tail = log.split('\n').filter(l => /error|FAILED|What went wrong|Execution failed|Could not|Unresolved|AAPT/i.test(l)).slice(-40).join('\n');
  const files = new Set(errors.map(e => e.file).filter(f => f.startsWith('app/src/')));
  const sources = [];
  for (const f of files) {
    try { sources.push({ path: f, content: fs.readFileSync(path.join(dir, f), 'utf8') }); } catch {}
  }
  return { errors: errors.slice(0, 40), tail, sources };
}
