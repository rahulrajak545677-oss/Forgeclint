import fs from 'fs';
import path from 'path';

const w = (dir, rel, text) => { const p = path.join(dir, rel); fs.mkdirSync(path.dirname(p), { recursive: true }); fs.writeFileSync(p, text); };

export const MAIN_DEFAULT_MANIFEST = pkg => `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <application
        android:allowBackup="true"
        android:label="@string/app_name"
        android:icon="@android:drawable/sym_def_app_icon"
        android:theme="@style/Theme.Generated">
        <activity android:name="${pkg}.MainActivity" android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
`;

const THEME = `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.Generated" parent="Theme.Material3.DayNight.NoActionBar" />
</resources>
`;

// Build scripts are owned by AutoForge. The model can never modify them.
export function writeScaffold(dir, { pkg, mode }) {
  const compose = mode === 'compose';
  w(dir, 'settings.gradle.kts', `pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement { repositories { google(); mavenCentral() } }
rootProject.name = "GeneratedApp"
include(":app")
`);
  w(dir, 'build.gradle.kts', `plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "2.0.20" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.20" apply false
}
`);
  w(dir, 'gradle.properties', 'org.gradle.jvmargs=-Xmx2g\nandroid.useAndroidX=true\nandroid.nonTransitiveRClass=true\nkotlin.code.style=official\n');
  w(dir, 'app/build.gradle.kts', `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
${compose ? '    id("org.jetbrains.kotlin.plugin.compose")\n' : ''}}
android {
    namespace = "${pkg}"
    compileSdk = 34
    defaultConfig {
        applicationId = "${pkg}"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    buildFeatures { ${compose ? 'compose = true' : 'viewBinding = true'} }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    lint { abortOnError = false }
}
dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.activity:activity-ktx:1.9.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.6")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.6")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("androidx.datastore:datastore-preferences:1.1.1")
${compose ? `    implementation(platform("androidx.compose:compose-bom:2024.09.03"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("androidx.navigation:navigation-compose:2.8.2")
` : ''}}
`);
}

export function writeDefaults(dir, pkg) {
  const has = rel => fs.existsSync(path.join(dir, rel));
  if (!has('app/src/main/AndroidManifest.xml')) w(dir, 'app/src/main/AndroidManifest.xml', MAIN_DEFAULT_MANIFEST(pkg));
  if (!has('app/src/main/res/values/themes.xml')) w(dir, 'app/src/main/res/values/themes.xml', THEME);
}

export const ALLOWED_DEPS_TEXT = `Fixed dependencies (you cannot add others): androidx core-ktx, appcompat, material (Material3), constraintlayout, recyclerview, activity-ktx, lifecycle viewmodel/runtime, kotlinx-coroutines-android, datastore-preferences` +
  `; Compose mode also has: Compose BOM 2024.09 (ui, material3, material-icons-extended), activity-compose, lifecycle-viewmodel-compose, navigation-compose. minSdk 26, compileSdk 34. No Room, no Retrofit, no Hilt, no Coil, no Firebase, no Google Play Services, no kapt/ksp.`;
export { w as writeFile };
