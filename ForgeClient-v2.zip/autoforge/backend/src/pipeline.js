import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { execFile } from 'child_process';
import { promisify } from 'util';
import { saveJob, jobDir } from './store.js';
import { planner, uiDesigner, developer, repair } from './agents.js';
import { build, analyze } from './builder.js';
import { writeScaffold, writeDefaults, writeFile } from './template.js';

const run = promisify(execFile);
const MAX_REPAIRS = +(process.env.MAX_REPAIR_ATTEMPTS || 5);
const PKG_RE = /^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/;

function step(job, stage, progress, msg) {
  job.stage = stage; job.progress = progress; job.log.push(`[${stage}] ${msg}`); saveJob(job);
}

// Security: model output can only create files under app/src/main/, no traversal, no scripts/binaries.
function applyFiles(dir, files) {
  let n = 0;
  for (const f of files) {
    const rel = path.posix.normalize(f.path.replace(/\\/g, '/'));
    if (!rel.startsWith('app/src/main/') || rel.includes('..')) continue;
    if (!/\.(kt|java|xml|json|txt|md)$/.test(rel)) continue;
    writeFile(dir, rel, f.content); n++;
  }
  return n;
}

export async function runJob(job) {
  job.status = 'running'; saveJob(job);
  const dir = path.join(jobDir(job.id), 'project');
  try {
    step(job, 'planner', 5, 'Understanding your idea and choosing defaults');
    const plan = await planner(job.prompt, job.options);
    if (!PKG_RE.test(plan.packageName || '')) plan.packageName = 'com.autoforge.gen.app' + crypto.randomBytes(3).toString('hex');
    job.plan = plan; step(job, 'planner', 12, `Plan ready: ${plan.appName}`);

    step(job, 'ui', 18, 'Designing the interface');
    const design = await uiDesigner(plan, job.options);

    step(job, 'developer', 28, 'Writing source code');
    const files = await developer(plan, design, job.options);
    fs.mkdirSync(dir, { recursive: true });
    writeScaffold(dir, { pkg: plan.packageName, mode: job.options.mode });
    const n = applyFiles(dir, files); writeDefaults(dir, plan.packageName);
    step(job, 'developer', 45, `Wrote ${n} files`);

    let apk = null;
    for (let attempt = 0; attempt <= MAX_REPAIRS; attempt++) {
      job.attempts = attempt + 1;
      step(job, 'build', 50 + attempt * 6, `Building APK (attempt ${attempt + 1})`);
      const res = await build(dir);
      if (res.ok) { apk = res.apk; break; }
      if (attempt === MAX_REPAIRS) { fs.writeFileSync(path.join(jobDir(job.id), 'build.log'), res.log); throw new Error('Build still failing after ' + MAX_REPAIRS + ' repair attempts'); }
      step(job, 'analyze', 50 + attempt * 6 + 2, 'Build failed, analyzing errors');
      const analysis = analyze(res.log, dir);
      if (!analysis.errors.length && !analysis.tail) throw new Error('Build failed without readable errors: ' + res.log.slice(-300));
      step(job, 'repair', 50 + attempt * 6 + 3, `Repairing ${analysis.errors.length} error(s)`);
      const fixes = await repair(job.plan, analysis, attempt + 1, job.options);
      applyFiles(dir, fixes);
      writeDefaults(dir, plan.packageName);
    }

    step(job, 'export', 92, 'Exporting APK and source');
    fs.copyFileSync(apk, path.join(jobDir(job.id), 'app.apk'));
    await run('zip', ['-qr', path.join(jobDir(job.id), 'source.zip'), '.', '-x', '.gradle/*', 'build/*', 'app/build/*'], { cwd: dir });
    fs.rmSync(path.join(dir, '.gradle'), { recursive: true, force: true });
    job.apk = true; job.status = 'done'; step(job, 'done', 100, 'APK ready (debug-signed)');
  } catch (e) {
    job.status = 'failed'; job.error = String(e.message || e).slice(0, 500);
    step(job, 'failed', job.progress, job.error);
  }
}
